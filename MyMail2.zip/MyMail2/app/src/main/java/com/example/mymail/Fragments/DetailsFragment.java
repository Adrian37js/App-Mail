package com.example.mymail.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.example.mymail.R;

import androidx.appcompat.app.AppCompatActivity;

public class DetailsFragment extends AppCompatActivity {

    private TextView details;
    private String text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        if (getIntent().getExtras() != null) {
            text = getIntent().getStringExtra("text");
        }
        DetailsFragment detailsFragment = (DetailsFragment) getSupportFragmentManager().findFragmentById(R.id.detailsFragment);
        detailsFragment.renderText(text);
    }

    public DetailsFragment() {
        // Required empty public constructor    }
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_details, container, false);
     details = (TextView) view.findViewById(R.id.textViewDetails);
     // Inflate the layout for this fragment
        return view;
    }

    public void renderText(String text) {
        details.setText(text);

    }
}
}
