package com.example.mymail.Activities;

public class DetailsActivity {
}
